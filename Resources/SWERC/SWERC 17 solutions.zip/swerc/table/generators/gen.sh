echo 200 200 3 3 400 50 100 | ./generate > test.03.in
echo 200 200 50 50 100 100 50 | ./generate > test.04.in
echo 2000 2000 3 3 20000 1000 1000 | ./generate > test.05.in
echo 2000 2000 1 1 200 1000 1000 | ./generate > test.06.in
echo 2000 2000 400 400 5000 1000 1000 | ./generate > test.07.in
