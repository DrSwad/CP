
open Format

let dishes = [|
  "Foie gras";
  "Huîtres";
  "Bœuf bourguignon";
  "Magret de canard";
  "Lapin à la moutarde";
  "Crème brûlée";
  "Mouse au chocolat";
             |]
let dish () = dishes.(Random.int (Array.length dishes))

let () = Random.self_init ()
let n = Random.int 100_001
let () = eprintf "N = %d@." n
let sum = ref 0
let () =
  for i = 1 to n do
    printf "%s@." (dish ());
    let price = Random.int 1001 and count = Random.int 11 in
    printf "%d %d@." price count;
    sum := !sum + price * count;
  done;
  printf "TOTAL@.";
  let t = if Random.bool () then !sum else max 0 (!sum - 3 + Random.int 7) in
  printf "%d@." t;
  eprintf "ans = %s@." (if t = !sum then "PAY" else "PROTEST")

