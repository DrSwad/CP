#!/usr/bin/python

import sys

cons = 0
pay = None
while pay == None:
    dk = sys.stdin.readline()
    ik = sys.stdin.readline()
    if dk.startswith("TOTAL"):
        pay = int(ik.split()[0])
    else:
        pk,ck =  ik.split()
        cons += int(pk)*int(ck)

if pay <= cons:
    print("PAY")
else:
    print("PROTEST")
