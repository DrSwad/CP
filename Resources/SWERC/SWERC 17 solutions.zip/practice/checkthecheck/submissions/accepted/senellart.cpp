#include <iostream>
#include <string>

using namespace std;

int main()
{
  bool finished=false;
  unsigned total=0;
  while(!finished) {
    string line;
    getline(cin, line);

    if(line=="TOTAL") {
      finished=true;

      unsigned displayed_total;

      cin >> displayed_total;

      if(total>=displayed_total)
        cout << "PAY";
      else
        cout << "PROTEST";
      cout << endl;
    } else {
      unsigned price;
      unsigned count;
      cin >> price >> count;
      
      // Get rid of the newline
      getline(cin, line);

      total += price*count;
    }
  }
}
