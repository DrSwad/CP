// Jean-Christophe

import java.util.Scanner;

class CheckTheCheck {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        long total = 0;
        while (true) switch (in.nextLine()) {
            case "TOTAL":
                long check = in.nextLong();
                System.out.println(check > total ? "PROTEST" : "PAY");
                System.exit(0);
            default:
                total += in.nextInt() * in.nextInt(); // order does not matter
                in.nextLine(); // to skip the newline
            }
    }
}
