#!/usr/bin/python
# by Sam

from functools import reduce
from operator import mul
import sys

lines = [reduce(mul, [int(x) for x in s.split()]) for s in sys.stdin.readlines()[1::2]]
print("PAY" if lines[-1] <= sum(lines[:-1]) else "PROTEST")
