#! /usr/bin/env python3
#

import sys

def read_ints(line = None):
    strs = (line or sys.stdin.readline()).split()
    assert all(s == "0" or not s.startswith("0") for s in strs), \
            "leading 0 detected"
    return tuple(int(s) for s in strs)

if __name__ == '__main__':
    n=0
    total = False
    for line in sys.stdin:
        n+=1
        if n % 2 == 1:
            assert(not total)
            assert(len(line)<=1001) # Including newline character
            if line.rstrip() == "TOTAL":
                total = True
        else:
            ints=read_ints(line)
            if total:
                assert(len(ints) == 1)
                assert(ints[0]>=0 and ints[0]<=2000000000)
            else:
                assert(len(ints) == 2)
                assert(ints[0] >= 0 and ints[0] <= 1000)
                assert(ints[1] >= 0 and ints[1] <= 10)

    assert(total)
    assert(n <= 200002)
    exit(42)
