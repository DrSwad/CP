#! /usr/bin/env python3
#

import sys

def read_ints(line = None):
    strs = (line or sys.stdin.readline()).split()
    assert all(s == "0" or not s.startswith("0") for s in strs), \
            "leading 0 detected"
    return tuple(int(s) for s in strs)

def assert_ascii(s):    
    for c in s :
        assert(ord(c) < 128 and ord(c) > 32 for c in s)
        
if __name__ == '__main__':
    [n,k] = read_ints()
    assert(n >= 0 and n <= 1000)
    assert(k >= 0 and k <= 1000)
    for line in sys.stdin:
        n-=1
        strs=tuple(line.split())
        assert(len(strs)==4)
        assert_ascii(strs[1])
        assert_ascii(strs[2])
        assert(strs[0]=="BEF" or strs[0]=="SIM")
        assert(len(strs[1])<=1000 and len(strs[2])<=1000)
        assert(int(strs[3]) >= 0 and int(strs[3])<=1000)

    assert(n==0)
    exit(42)
