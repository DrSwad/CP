#!/bin/bash

t=$(mktemp);
g++ sol_louis.cc -O2 -o sol
g++ gen.cc -O2 -o gen
./gen ;
for i in *.in ; do
    echo $i
    ./sol < $i > ${i%%in}ans ;
    time python sol_louis.py < $i > $t
    diff $t ${i%%in}ans ; 
done ;
rm $t
