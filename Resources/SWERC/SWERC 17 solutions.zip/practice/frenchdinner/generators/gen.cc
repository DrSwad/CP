#include <cstdio>
#include <cstdlib>

int dist[1000] ;

int abs(int a)
{
  if(a<0)
    return -a;
  return a;
}
void printnb(int n)
{
  if(!n)
    printf("Z ");
  else
    {
      printf("%c",(n%3)["O2T"]);
      printnb(n/3);
    }
}


void gen1()
{
  printf("1000 %d\n",1000-rand()%8);
  for(int i = 0 ; i < 400 ; i++ )
    dist[i] = rand()% 1000  ;
  for(int i = 0 ; i < 1000 ; i++ )
    {
      int cur = i%400 ;
      int ot = (i+1+(rand()%100))%400 ;
      if(dist[cur] < dist[ot])
        {
          cur = ot ;
          ot = i ;
        }
      int nu = dist[cur]-dist[ot];
      if(i%3)
        printf("SIM ") ;
      else
        printf("BEF ");

      printnb(ot) ;
      printnb(cur) ;
      printf("%d\n",nu);
    }
}

void gen2()
{
  printf("1000 1000\n");
  for(int i = 0 ; i < 400 ; i++ )
    dist[i] = rand()% 1000  ;
  for(int i = 0 ; i < 1000 ; i++ )
    {
      int cur = i%400 ;
      int ot = (i+1+(rand()%100))%400 ;
      if(dist[cur] < dist[ot])
        {
          cur = ot ;
          ot = i ;
        }
      int nu = dist[cur]-dist[ot]+((i%100)/99);
      if(i%3)
        printf("BEF ");
      else
        printf("SIM ") ;

      printnb(ot) ;
      printnb(cur) ;
      printf("%d\n",nu);
    }
}

void open(int r, int i)
{
  char s[100];
  sprintf(s,"gen_%d_test_%d.in",r,i);
  freopen(s,"w",stdout);
}
int main()
{
  for(int i = 0 ; i < 10 ; i++)
    open(1,i),gen1();
  for(int i = 0 ; i < 10 ; i++)
    open(2,i),gen2();
  return 0;
}
