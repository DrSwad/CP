#include <cstdio>
#include <map>
#include <string>
#include <vector>

struct edge
{
  int from, to, weight ;
  edge(int a, int b, int c) : from(a),to(b), weight(c) {} 
} ;

using namespace std ;

const int Tm = 2003 ;
const int INF = 1000*1000*1000 ;

int dist[Tm] ;
int nbRules, totalTime, cur_id ;
map<string,int> trans ;
vector<edge> edges ;

int remap(char * s)
{
  if(trans.find(s) == trans.end())
    trans[s] = cur_id ++ ;
  return trans[s];
}

bool read_input()
{
  if(scanf("%d %d\n",&nbRules,&totalTime) < 2)
    return false;
  char type[81], as[81], bs[81] ;
  int n, a, b ;
  for(int r = 0 ; r < nbRules ; r++ )
    {
      scanf("%s %s %s %d\n",type,as,bs,&n);
      a = remap(as);
      b = remap(bs);
      if(type[0]=='B') // BEF A B N  is equivalent to w[a] ≤ w[b] - n 
        {
          edges.push_back(edge(b,a,-n));
        }
      else
        {
          // SIM A B N is equivalent to
          //            w[a] ≤ w[b]+n
          //            w[b] ≤ w[a]+n
          edges.push_back(edge(a,b,n));
          edges.push_back(edge(b,a,n));
        }
    }
  // We add a end node and a start node
  for(int n = 0 ; n < cur_id ; n++ )
    {
      edges.push_back(edge(n,cur_id,0)) ; // ∀n : w[start] ≤ w[n]
      edges.push_back(edge(cur_id+1,n,0)) ; // ∀n : w[n] ≤ w[end]
    }
  edges.push_back(edge(cur_id,cur_id+1,totalTime)) ; // w[end] ≤  w[start] + totalTime
  edges.push_back(edge(cur_id+1,cur_id,0)) ; // w[start] ≤  w[end]
  
  cur_id += 2 ;
}

bool is_negative_cycle()
{
  fill(dist,dist+cur_id, totalTime);
  bool changed = true ;
  for( int step = 0 ; changed && step <= cur_id ; step++ )
    {
      changed = false ;
      for(auto e : edges )
        if( dist[e.to] > dist[e.from] + e.weight )
          {
            dist[e.to] = dist[e.from] + e.weight ;
            changed = true ;
          }
    }
  return changed ;
}

int main ()
{
  read_input();
  if(is_negative_cycle())
    printf("NO\n");
  else
    printf("YES\n");
}
