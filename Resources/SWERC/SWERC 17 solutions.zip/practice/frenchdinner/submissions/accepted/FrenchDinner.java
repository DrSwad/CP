// Jean-Christophe
// NOTE: reads a single problem

import java.util.*;

class Edge {
    int dst; int weight;
    Edge(int dst, int weight) { this.dst = dst; this.weight = weight; }
}

class FrenchDinner {
    // the graph maps vertices to edges, but a single list of all edges
    // would be enough for this problem
    static Vector<Vector<Edge>> edges = new Vector<>();

    static HashMap<String, Integer> nodes = new HashMap<>();
    static int node(String s) {
        if (nodes.containsKey(s)) return nodes.get(s);
        int v = edges.size();
        edges.add(new Vector<Edge>());
        nodes.put(s, v);
        return v;
    }
    static int start = node(" start");
    static int end   = node(" end");

    // add the constraint time[a] <= time[b] + d
    static void constraint(int a, int b, int d) {
        edges.get(b).add(new Edge(a, d));
    }

    static int V, K; // known when we are done reading the input

    static boolean hasNegativeCycle() { // Bellman-Ford
        int[] dist = new int[V];
        for (int i = 0; i < V; i++) dist[i] = 2001;
        dist[start] = 0;
        for (int step = 1; step <= V; step++) {
            boolean change = false;
            for (int v = 0; v < V; v++)
                for (Edge e: edges.get(v))
                    if (dist[v] + e.weight < dist[e.dst]) {
                        if (step == V) return true;
                        dist[e.dst] = dist[v] + e.weight;
                        change = true;
                    }
            if (!change) return false; // OPTIM
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int N = in.nextInt();
        K = in.nextInt();
        constraint(end, start, K); // total time should be no more than K
        while (N-- > 0) {
            String rule = in.next();
            int a = node(in.next());
            int b = node(in.next());
            int m = in.nextInt();
            if (rule.equals("BEF"))
                constraint(a, b, -m);
            else if (rule.equals("SIM")) {
                constraint(a, b, m);
                constraint(b, a, m);
            } else assert false;
        }
        in.close();
        V = nodes.size();
        // System.err.println(V + " nodes");
        for (int v = 2; v < V; v++) {
            constraint(start, v, 0); // start before v
            constraint(v,   end, 0); // v before end
        }
        System.out.println(hasNegativeCycle() ? "NO" : "YES");
    }
}

// Local Variables:
// compile-command: "javac FrenchDinner.java && java Main < in"
// End:
