#!/usr/bin/env python

import sys
dist = [0] * 2003
edges = [] # list of (from, to, dist)
remap = dict()
nb_remaps=2

def get_remap(x):
    global nb_remaps, remap
    if not x in remap:
        remap[x]=nb_remaps
        nb_remaps+=1
    return remap[x]

nbRules, totalTime = map(int,sys.stdin.readline().split())

for i in range(nbRules):
    t,a,b,n = sys.stdin.readline().split()
    n = int(n)
    a=get_remap(a)
    b=get_remap(b)
    if t=="BEF":
        edges.append((b,a,-n))
    else:
        edges.append((a,b,n))

edges.append((0,1,totalTime))# 0 is start of meal, 1 is the end
for n in range(nb_remaps):
    edges.append((n,0,0))
    edges.append((1,n,0))


changed = True
step = 0
while step <= nb_remaps and changed:
    step+=1
    changed = False
    for (f,t,d) in edges:
        if dist[t] > dist[f]+d:
            changed=True
            dist[t] = dist[f]+d
        
if changed:
    print("NO")
else:
    print("YES")
