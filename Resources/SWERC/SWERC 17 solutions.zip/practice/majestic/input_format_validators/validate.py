#! /usr/bin/env python3
#

import sys

def read_ints(line = None):
    strs = (line or sys.stdin.readline()).split()
    assert all(s == "0" or not s.startswith("0") for s in strs), \
            "leading 0 detected"
    return tuple(int(s) for s in strs)

if __name__ == '__main__':
    [s] = read_ints()
    assert(s >= 1 and s <= 11000)

    [n1,k1,d1,t1] = read_ints()
    assert(n1 >= 1 and n1 <= 1000)
    assert(k1 >= 1 and k1 <= 64)
    assert(d1 >= 1 and d1 <= 8)
    assert(t1 >= 1 and t1 <= 1000)

    slots=dict()

    for i in range(0,n1):
        [d,h,m,t] = read_ints()
        assert(d >= 1 and d <=8)
        assert(h >= 8 and h <= 20)
        assert(m >=0 and m <= 59)
        assert(t >=0 and t < t1)
        if not (t in slots):
            slots[t]=dict()
        if d in slots[t]:
            slots[t][d].append(60*h+m)
        else:
            slots[t][d]=[60*h+m]

    for t in slots:
        for d in slots[t]:
            slots[t][d].sort()
            old=-1000
            for v in slots[t][d]:
                assert(old+d1 <= v)
                old=v

    [n2,k2,d2,t2] = read_ints()
    assert(n2 >= 1 and n2 <= 1000)
    assert(k2 >= 1 and k2 <= 64)
    assert(d2 >= 1 and d2 <= 8)
    assert(t2 >= 1 and t2 <= 1000)
    
    slots=dict()

    for i in range(0,n2):
        [d,h,m,t] = read_ints()
        assert(d >= 1 and d <=8)
        assert(h >= 8 and h <= 20)
        assert(m >=0 and m <= 59)
        assert(t >=0 and t < t2)
        
        if not (t in slots):
            slots[t]=dict()
        if d in slots[t]:
            slots[t][d].append(60*h+m)
        else:
            slots[t][d]=[60*h+m]
    
    for t in slots:
        for d in slots[t]:
            slots[t][d].sort()
            old=-1000
            for v in slots[t][d]:
                assert(old+d2 <= v)
                old=v

    [c] = read_ints()
    assert(c>= 0 and c <= t1*t2)

    for k in range(0,c):
        [i,j]=read_ints()
        assert(i >= 0 and i < t1)
        assert(j >= 0 and j < t2)

    assert(sys.stdin.read()=="")

    exit(42)
