#include <cstdio>
#include <map>
#include <queue>
#include <set>
#include <vector>

using ::std::make_pair;
using ::std::map;
using ::std::pair;
using ::std::queue;
using ::std::set;
using ::std::vector;

struct slot {
  unsigned char day;
  int time;
  int teacher;
};

pair<vector<int>, int> path(const vector<vector<int>>& G,
                            const vector<map<int, int>>& H,
                            const vector<int>& capacityf,
                            const vector<int>& capacityi, int N1) {
  vector<bool> used(N1, false);
  queue<pair<vector<int>, int>> todo;
  for (int i = 0; i < N1; ++i) {
    if (capacityf[i] > 0) {
      todo.emplace(vector<int>(1, i), capacityf[i]);
    }
  }
  while (!todo.empty()) {
    pair<vector<int>, int> p = todo.front();
    todo.pop();
    if (used[p.first.back()]) {
      continue;
    }
    used[p.first.back()] = true;
    for (int i : G[p.first.back()]) {
      if (capacityi[i] > 0) {
        if (capacityi[i] < p.second) {
          p.second = capacityi[i];
        }
        p.first.push_back(i);
        return p;
      }
      for (auto m : H[i]) {
        if (m.second > 0) {
          pair<vector<int>, int> q = p;
          q.first.push_back(i);
          q.first.push_back(m.first);
          if (m.second < q.second) {
            q.second = m.second;
          }
          todo.push(q);
        }
      }
    }
  }
  return {{}, 0};
}

int flow(int N1, int K1, int N2, int K2, const vector<vector<int>>& G) {
  int f = 0;
  vector<map<int, int>> H(N2);
  vector<int> capacityf(N1, K1);
  vector<int> capacityi(N2, K2);
  pair<vector<int>, int> p = path(G, H, capacityf, capacityi, N1);
  while (p.second > 0) {
    capacityf[p.first[0]] -= p.second;
    H[p.first[1]][p.first[0]] += p.second;
    for (unsigned int j = 2; j < p.first.size(); j += 2) {
      H[p.first[j - 1]][p.first[j]] -= p.second;
      H[p.first[j + 1]][p.first[j]] += p.second;
    }
    capacityi[p.first.back()] -= p.second;
    f += p.second;
    p = path(G, H, capacityf, capacityi, N1);
  }
  return f;
}

unsigned char part[6][20] = {
    {1, 2, 4, 8, 16, 32},
    {3, 5, 6, 9, 10, 12, 17, 18, 20, 24, 33, 34, 36, 40, 48},
    {7,  11, 13, 14, 19, 21, 22, 25, 26, 28,
     35, 37, 38, 41, 42, 44, 49, 50, 52, 56},
    {15, 23, 27, 29, 30, 39, 43, 45, 46, 51, 53, 54, 57, 58, 60},
    {31, 47, 55, 59, 61, 62},
    {63}};
int partsize[6] = {6, 15, 20, 15, 6, 1};

int main() {
  int S, N1, K1, D1, T1, N2, K2, D2, T2, C;
  scanf("%d%d%d%d%d", &S, &N1, &K1, &D1, &T1);
  vector<slot> french;
  for (int n = 0; n < N1; ++n) {
    int d, h, m, t;
    scanf("%d%d%d%d", &d, &h, &m, &t);
    french.push_back({d - 1, 60 * h + m, t});
  }
  scanf("%d%d%d%d", &N2, &K2, &D2, &T2);
  vector<slot> italian;
  for (int n = 0; n < N2; ++n) {
    int d, h, m, t;
    scanf("%d%d%d%d", &d, &h, &m, &t);
    italian.push_back({d - 1, 60 * h + m, t});
  }
  set<pair<int, int>> conflicts;
  scanf("%d", &C);
  for (int c = 0; c < C; ++c) {
    int i, j;
    scanf("%d%d", &i, &j);
    conflicts.emplace(i, j);
  }
  int best = 100;
  for (int size = 0; size < 6; ++size) {
    for (int xi = 0; xi < partsize[size]; ++xi) {
      unsigned char x = part[size][xi];
      vector<vector<int>> G(N1);
      for (int i = 0; i < N1; ++i) {
        const slot& fc = french[i];
        if (((1 << fc.day) & x) == 0) {
          continue;
        }
        for (int j = 0; j < N2; ++j) {
          const slot& ic = italian[j];
          if (((1 << ic.day) & x) == 0) {
            continue;
          }
          if (conflicts.count(make_pair(fc.teacher, ic.teacher)) > 0) {
            continue;
          }
          if (fc.day == ic.day && !(fc.time + D1 * 60 + 5 <= ic.time ||
                                    ic.time + D2 * 60 + 5 <= fc.time)) {
            continue;
          }
          G[i].push_back(j);
        }
      }
      if (flow(N1, K1, N2, K2, G) >= S) {
        printf("%d\n", size + 1);
        return 0;
      }
    }
  }
  printf("0\n");
  return 0;
}
