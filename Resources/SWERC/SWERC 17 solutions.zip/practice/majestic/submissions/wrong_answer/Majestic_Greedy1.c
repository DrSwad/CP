#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

struct Slot{
    unsigned char m_day;
    int m_start;
    int m_origindex;
    int m_teacher;
};

typedef struct Slot Slot;

#define MAXN 1000

struct AdjList{
    int m_count;
    int m_members[MAXN];
    int m_degree;
};

typedef struct AdjList AdjList;


int S, N1, N2, K1, K2, D1, D2, N, T1, T2, C, newN1, newN2;
Slot FCSlots [MAXN], ICSlots[MAXN];
Slot crtFCSlots [MAXN], crtICSlots[MAXN];

AdjList neighbours[2*MAXN];
int cap[MAXN*2];
int conflicts[MAXN][MAXN];

int order[MAXN*2];

unsigned char masks[6][20] = {{1,2,4,8,16,32},
                            {3,5,6,9,10,12,17,18,20,24,33,34,36,40,48},
                            {7,11,13,14,19,21,22,25,26,28,35,37,38,41,42,44,49,50,52,56},
                            {15,23,27,29,30,39,43,45,46,51,53,54,57,58,60}, 
                            {31,47,55,59,61,62},
                            {63}};                 
int countmasks[] = {6,15,20,15,6,1};

unsigned char glomask;

void readData()
{
    int day, hour, min, c, i, j;
    size_t ret;
    
    glomask = 0;

    ret = scanf("%d%d%d%d%d",&S, &N1, &K1, &D1, &T1);
    D1*=60;
    for (i = 0; i < N1; ++i) {
        ret = scanf("%d%d%d%d", &day, &hour, &min, &FCSlots[i].m_teacher);
        FCSlots[i].m_day =  ((unsigned char)1) << (day-1);
        FCSlots[i].m_start = 60*hour + min;
        glomask |= FCSlots[i].m_day;
    }

    ret = scanf("%d%d%d%d",&N2, &K2, &D2, &T2);
    D2*=60;
    for (i = 0; i < N2; ++i) {
        ret = scanf("%d%d%d%d", &day, &hour, &min, &ICSlots[i].m_teacher);
        ICSlots[i].m_day = ((unsigned char)1) << (day-1);
        ICSlots[i].m_start = 60*hour+min;
        glomask |= ICSlots[i].m_day;
    }
    
    for (i = 0; i < T1; ++i)
        for (j = 0; j < T2; ++j)
            conflicts[i][j] = 0;
    
    scanf("%d",&C);
    for (c = 0; c < C; ++c) {
        scanf("%d%d", &i, &j);
        conflicts[i][j] = 1;
    }
        
    (void)ret;
    
    
}

int overlaps (Slot fcslot, Slot icslot)
{
    static const int delta = 5;
    if (conflicts[fcslot.m_teacher][icslot.m_teacher]) 
        return 1;
   
        
    if (icslot.m_day != fcslot.m_day)
        return 0;
    if (icslot.m_start >= fcslot.m_start + D1 + delta || fcslot.m_start >= icslot.m_start + D2 + delta)
        return 0;
        
    return 1;
}

void buildGraph(unsigned char mask)
{
    int i,j;
    
    newN1 = 0;
    newN2 = 0;
  
    for (i = 0; i < N1; ++i) 
        if (FCSlots[i].m_day&mask) {
            crtFCSlots[newN1] = FCSlots[i];
            crtFCSlots[newN1].m_origindex = i;
            newN1++;
        }
    for (i = 0; i < N2; ++i)
        if (ICSlots[i].m_day&mask) {
            crtICSlots[newN2] = ICSlots[i];
            crtICSlots[newN2].m_origindex = i;
            newN2++;
        }
    for (i = 0; i<newN1+newN2; ++i) {
        neighbours[i].m_count = 0;
        if (i <newN1)
            cap[i] = K1;
        else
            cap[i] = K2;
    }    
           
    for (i = 0; i < newN1; ++i) {
        for (j = 0; j < newN2; ++j)
            if (!overlaps(crtFCSlots[i], crtICSlots[j])) {
                neighbours[i].m_members[neighbours[i].m_count] = j+newN1;
                neighbours[i].m_count++;
                neighbours[j+newN1].m_members[neighbours[j+newN1].m_count] = i;
                neighbours[j+newN1].m_count++;
            }
    }
    for (i = 0; i<newN1+newN2; ++i)
        neighbours[i].m_degree = neighbours[i].m_count;
    

}

int findneighbour(int i) {
    int j;
    for (j = 0; j < neighbours[i].m_count; ++j) {
        if (cap[neighbours[i].m_members[j]] > 0)
            return neighbours[i].m_members[j];
    }
    return -1;
}

void decreaseneighbdegree(int i) {
    int j, k;
    for (j = 0; j < neighbours[i].m_count; ++j) {
        k = neighbours[i].m_members[j];
        neighbours[k].m_degree--;
    }
}


int assignWithMask(unsigned char mask)
{
    int i, j, Sremain, aux, min;
     
    buildGraph(mask);
    N = newN1 + newN2;
        
    Sremain = S;
    while (Sremain > 0)
    {
          //sort according to degree
          for (i = 0; i < N; ++i)
                order[i] = i;
          for (i = 0; i < N; ++i)
            for (j= i+1; j<N; ++j)
                if (neighbours[order[i]].m_degree > neighbours[order[j]].m_degree) {
                    aux = order[i]; order[i] = order[j]; order[j] = aux;
                }
    
           i = 0;
           while (i < N && (!cap[order[i]] || !neighbours[order[i]].m_degree))   
                ++i;
           if (i == N)
                return 0; //could not assign students
            
           j = findneighbour(order[i]); 
          
           if (j == -1)
                exit(1);
           
           min = cap[order[i]];
           if (cap[j] < min)
                min = cap[j];
  
                
           cap[order[i]]-=min;
           if (cap[order[i]] == 0)
                decreaseneighbdegree(order[i]);
           cap[j]-=min;
           if (cap[j] == 0)
                decreaseneighbdegree(j);   
           
           Sremain -=min;
    }
    return 1;
}
 
void solve()
{
    int i, j;
    
    for (i = 0; i< 6; ++i) 
        for (j = 0; j<countmasks[i]; ++j) 
            if ((glomask&masks[i][j]) == masks[i][j] && assignWithMask(masks[i][j])) {
                printf("%d\n", i+1);
                return;
            }
    printf("0\n");
}


int main(int argc, char** argv)
{
    (void)argc;
    (void)argv;

    readData();
    solve();
  
    return 0;
}

