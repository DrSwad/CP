import java.util.Scanner;

public class Majestic{
	
	static final int MAXN = 1000;
	static final int delta = 5;
    static final char[][] masks = {{1,2,4,8,16,32},
	                            {3,5,6,9,10,12,17,18,20,24,33,34,36,40,48},
	                            {7,11,13,14,19,21,22,25,26,28,35,37,38,41,42,44,49,50,52,56},
	                            {15,23,27,29,30,39,43,45,46,51,53,54,57,58,60}, 
	                            {31,47,55,59,61,62},
	                            {63}};  
	                                           
	static final int[] countmasks = {6,15,20,15,6,1};
	
    static class Slot{
	    char m_day;
        int m_start;
        int m_teacher;
	};

	static class AdjList{
	    int m_count;
	    int[] m_members;
	    public AdjList() {
	        m_count = 0;
	        m_members = new int[MAXN];
	    }    
	};

	int S, N1, N2, K1, K2, D1, D2, T1, T2, N, C;
	Slot[] FCSlots;
	Slot[] ICSlots;
	int[][] rescap;
    int[][] conflicts;
    AdjList[] neighbours;
    int[] queue;
    int[] parent;
    int[] good;
    
	char glomask;

	public Majestic() 
	{
	   FCSlots = new Slot[MAXN]; 
	   ICSlots = new Slot[MAXN];
	   for (int i = 0; i< MAXN; ++i) {
	        FCSlots[i] = new Slot();
	        ICSlots[i] = new Slot();
	   }
	        

	   rescap = new int[MAXN*2+2][MAXN*2+2];
       conflicts = new int[MAXN][MAXN];
       
       neighbours = new AdjList[MAXN*2+2];
       for (int i = 0; i<MAXN*2+2; ++i)
            neighbours[i] = new AdjList();
        
       queue = new int[MAXN*2+2];
       parent = new int[MAXN*2+2];
       good = new int[MAXN*2+2];
	}

    void readData()
	{
	    int day, hour, min;
	    Scanner input = new Scanner( System.in );
	    glomask = 0;
	    
	    S = input.nextInt();
	    N1 = input.nextInt();
	    K1 = input.nextInt();
	    D1 = input.nextInt();
	    T1 = input.nextInt();  
	    D1*=60;
	    
	    
	    for (int i = 0; i < N1; ++i) {
	        day = input.nextInt();
	        hour = input.nextInt();
	        min = input.nextInt();
	        
	        FCSlots[i].m_day = (char) ( 1 << (day-1));
	        
	        FCSlots[i].m_start = 60*hour + min;
	        FCSlots[i].m_teacher = input.nextInt();
	        
	        glomask |= FCSlots[i].m_day;
	    }

	    N2 = input.nextInt();
	    K2 = input.nextInt();
	    D2 = input.nextInt();
	    T2 = input.nextInt(); 
	    D2*=60;
	    
	    for (int i = 0; i < N2; ++i) {
	    	day = input.nextInt();
	        hour = input.nextInt();
	        min = input.nextInt();
	        
	        ICSlots[i].m_day = (char) ( 1 << (day-1));
	      
	        ICSlots[i].m_start = 60*hour + min;
	        ICSlots[i].m_teacher = input.nextInt();
	        
	        glomask |= ICSlots[i].m_day;
	    }
	    
	    for (int i = 0; i < T1; ++i)
            for (int j = 0; j < T2; ++j)
                conflicts[i][j] = 0;
    
        C = input.nextInt();
        for (int c = 0; c < C; ++c) {
            int i = input.nextInt();
            int j = input.nextInt();
            conflicts[i][j] = 1;
        }
	}
	
		
    int overlaps (Slot fcslot, Slot icslot)
    {
        if (1 == conflicts[fcslot.m_teacher][icslot.m_teacher]) {
            return 1;
        }
        
        if (icslot.m_day != fcslot.m_day)
            return 0;
        if (icslot.m_start >= fcslot.m_start + D1 + delta || fcslot.m_start >= icslot.m_start + D2 + delta)
            return 0;
        
        return 1;
    }

    void buildGraph()
    {
    
        N = N1 + N2 + 2; //add source and sink
        for (int i = 0; i < N; ++i)
            neighbours[i].m_count = 0;

      
        for (int i = 0; i < N1; ++i)
            for (int j = 0; j < N2; ++j) 
            
                if (0 == overlaps(FCSlots[i], ICSlots[j])) {

                    neighbours[i+1].m_members[neighbours[i+1].m_count] = j+N1+1;
                    neighbours[i+1].m_count++;
                
                    neighbours[j+N1+1].m_members[neighbours[j+N1+1].m_count] = i+1;
                    neighbours[j+N1+1].m_count++;   
                }
    }


    int FlowWithMask(char mask)
    {
        int first, last, crtnode, nei, flow = 0, min, i, j, done, crtN1, crtN2;
    
        for (i = 0; i<N; ++i)
            good[i] = 0;
    
        crtN1  = crtN2 = 0;
        for (i = 0; i < N1; ++i)  
            if (0 != (FCSlots[i].m_day&mask)) {
                good[i+1] = 1;
                rescap[0][i+1] = K1;
                crtN1++;
            } else
                rescap[0][i+1] = 0;
            
        for (i = 0; i<N2; ++i)
            if (0 != (ICSlots[i].m_day&mask)) {
                good[i+N1+1] = 1;
                rescap[i+N1+1][N-1] = K2;
                crtN2++;
            } else
                rescap[i+N1+1][N-1] = 0; 
   
        //early exit 2
        if (S>crtN1*K1 && S>crtN2*K2) 
            return 0;
   
        for (i = 1; i <= N1; ++i) if (good[i] == 1)
             for (j = 0; j<neighbours[i].m_count; ++j) {
                    nei = neighbours[i].m_members[j];
                    if (0 == good[nei]) continue;

                    rescap[i][nei]=K1;
                    rescap[nei][i] = 0;
                }      
        
        for (i = 1; i <= N1; ++i)
        {
            while ((rescap[0][i]>0) && (flow!=S)) 
            {
                first = last =0;
                for (j = 0; j<N; ++j)
                    parent[j] = -1;
                parent[i] = 0;
	            queue[first] = i;
                while (first <= last) {
                    crtnode = queue[first];
                    for (j = 0; j<neighbours[crtnode].m_count; ++j) {
                        nei = neighbours[crtnode].m_members[j];
                        if ((0 == good[nei]) || (0 ==rescap[crtnode][nei]) || parent[nei]!=-1) continue;
                    
                        parent[nei] = crtnode;
                    
                        if (rescap[nei][N-1]>0) {
                            parent[N-1] = nei;
                       
                            first = last;
                            break;
                        }
                        last++;
                        queue[last] = nei;
                    }
                    first++;
                }
                if (parent[N-1] == -1) 
                    break;
                    
                crtnode = N-1;
                min = S-flow;
                while (crtnode != 0) {
                    nei = parent[crtnode];
               
                    if (rescap[nei][crtnode] < min)
                        min = rescap[nei][crtnode];
                    crtnode = nei;
                }
        
           
                flow += min;
        
                crtnode = N-1;
                while (crtnode != 0) {
                    nei = parent[crtnode];
                    rescap[nei][crtnode] -= min;
                    rescap[crtnode][nei] += min;
                    crtnode = nei;
                }
                if (flow == S) 
                    return 1;
            }
        }   
                       
        return 0;
    }
    
    void MaxFlow()
    {
        for (int i = 0; i< 6; ++i) 
            for (int j = 0; j<countmasks[i]; ++j) {
                if (((glomask&masks[i][j]) == masks[i][j]) && (0!=FlowWithMask(masks[i][j]))) {
                    System.out.println(i+1);
                    return;
                }
            }
        System.out.println("0");
    }


	public static void main(String[] args) {
	    Majestic maj  = new Majestic();

        maj.readData();    
        //early exit 1
        if (maj.S>maj.K1*maj.N1 && maj.S>maj.K2*maj.N2) {
            System.out.println(0);
            return;
        }
  
        maj.buildGraph();
        maj.MaxFlow();
    } 
}
