#!/usr/bin/env bash

for f in */*.in; do
  echo $f ...
  # let's hope that there is a single python file
  time ../submissions/accepted/*.py < $f > `dirname $f`/`basename $f .in`.ans
done
