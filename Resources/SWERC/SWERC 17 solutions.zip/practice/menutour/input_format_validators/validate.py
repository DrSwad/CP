#! /usr/bin/env python3
#

import sys

def read_ints(line = None):
    strs = (line or sys.stdin.readline()).split()
    assert all(s == "0" or not s.startswith("0") for s in strs), \
            "leading 0 detected"
    return tuple(int(s) for s in strs)

if __name__ == '__main__':
    [c,r,b] = read_ints()
    assert(c >= 1 and c <= 20)
    assert(r >= 1 and r <= 100)
    assert(b >= 0 and r <= 100)
    for line in sys.stdin:
        r-=1
        ints=tuple(map(int,line.split()))
        assert(len(ints) == c+2)
        assert(ints[0] >= 1 and ints[0] <= 1000)
        assert(ints[1] >= 1 and ints[1] <= 1000)
        for i in range(2,c+2):
            assert(ints[i] >= 0 and ints[i] <= 40)

    assert(r==0)
    exit(42)
