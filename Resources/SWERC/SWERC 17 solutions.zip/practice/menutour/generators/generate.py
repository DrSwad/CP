#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# c.durr - swerc - 2017

# Menu Tour

from random import randint, choice, seed

seed(2341325)

t = 0
def dump(C, R, B, i, j, P):
    global t
    t += 1
    with open("test{:02d}.in".format(t), "w") as fd:
        print("%i %i %i" % (C, R, B), file=fd)
        for r in range(R):
            sep = ''
            for v in [i[r], j[r]] + P[r]:
                print("%s%i" % (sep, v), file=fd, end='')
                sep = ' '
            print(file=fd)

# # the sample input
# print("""\
# 3 5 9
# 0 0 1 0 0
# 2 0 0 9 7
# 5 1 0 0 3
# 2 4 0 2 0
# 5 4 8 0 9""")

# single restaurant instance, feasible
C = 20
dump(C, 1, 40, [0], [0], [[1 + (c % 3) for c in range(C)]])

# two restaurants instance
R = 2
B = 40
i = list(range(R))
j = [0] * R
P = [[choice([0, 1, 1, 2, 2, 3, 3]) for c in range(C)] for r in range(R)]
dump(C, R, B, i, j, P)

# maximum range instance
C = 20
R = 100
B = 100
for test in range(8):
    i = [randint(1, 1000) for r in range(R)]
    j = [randint(1, 1000) for r in range(R)]
    P = []
    for r in range(R):
        P.append([])
        for c in range(C):
            if test == 3 or randint(0, 1):
                P[-1].append(randint(1, 40))
            else:
                P[-1].append(0)
    dump(C, R, B, i, j, P)
