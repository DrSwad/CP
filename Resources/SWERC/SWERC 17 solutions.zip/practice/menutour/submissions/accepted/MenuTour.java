// Jean-Christophe
// same algorithm as Christoph's, but using memoisation instead of DP

import java.util.*;

class Restaurant {
    int x, y;
    int[] courses;
    Restaurant(int x, int y, int[] courses) {
        this.x = x; this.y = y; this.courses = courses; }
    int dist(Restaurant that) {
        return Math.abs(this.x - that.x) + Math.abs(this.y - that.y); }
}

class MenuTour {

    static int R, C, B;
    static Restaurant[] restaurants;
    static HashMap<Integer, Integer> memo = new HashMap<>();

    static int solve(int c, int r, int b) {
        assert c < 256 && r < 256 && b < 256;
        int key = (c << 16) | (r << 8) | b;
        if (memo.containsKey(key)) return memo.get(key);
        int time = -1;
        int cost = restaurants[r].courses[c];
        if (cost != 0 && cost <= b)
            if (c == 0)
                time = 0;
            else
                for (int prevr = 0; prevr < R; prevr++) {
                    int dist = restaurants[prevr].dist(restaurants[r]);
                    int prevtime = solve(c-1, prevr, b - cost);
                    if (prevtime == -1) continue;
                    int newtime = prevtime + dist;
                    if (time == -1 || newtime < time) time = newtime;
                }
        memo.put(key, time);
        return time;
    }

    static int solve() {
        int time = -1;
        for (int r = 0; r < R; r++)
            for (int b = 0; b <= B; b++) {
                int trb = solve(C-1, r, b);
                if (trb == -1) continue;
                if (time == -1 || trb < time) time = trb;
            }
        memo.clear();
        return time;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        C = in.nextInt();
        R = in.nextInt();
        B = in.nextInt();
        restaurants = new Restaurant[R];
        for (int r = 0; r < R; r++) {
            int x = in.nextInt();
            int y = in.nextInt();
            int[] courses = new int[C];
            for (int c = 0; c < C; c++) courses[c] = in.nextInt();
            restaurants[r] = new Restaurant(x, y, courses);
        }
        System.out.println(solve());
    }
}

