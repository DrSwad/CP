/* Swerc 2017 Menu Tour - C. Dürr
 */

import java.util.*;

class Restaurant {
    int x, y;
    int[] courses;
    Restaurant(int x, int y, int[] courses) {
        this.x = x; this.y = y; this.courses = courses; }
    int dist(Restaurant that) {
        return Math.abs(this.x - that.x) + Math.abs(this.y - that.y); }
}

class MenuTour2 {

    static final int MAXC = 20;
    static final int MAXR = 200;
    static final int MAXB = 201;

    static int[][][] A = new int[MAXC][MAXR][MAXB];
    static int[][] P = new int[MAXR][MAXC];
    static int[] X = new int[MAXR];
    static int[] Y = new int[MAXR];

    static int courses, restaurants, budget;


    static int solve() {
        // initialize
        for (int c = 0; c < courses; ++c)
            for (int r = 0; r < restaurants; ++r)
                for (int b = 0; b <= budget; ++b)
                    A[c][r][b] = -1;              // represents +infinity cost
        // base step c = 0
        for (int r = 0; r < restaurants; ++r)
        {
            int b = P[r][0];
            if (b != 0)
                A[0][r][b] = 0;
        }
        // induction step
        for (int c = 1; c < courses; ++c)
            for (int r = 0; r < restaurants; ++r)
                for (int b = 0; b <= budget; ++b)
                {
                    int a = P[r][c];
                    if (1 <= a && a <= b)
                        for (int i = 0; i < restaurants; ++i)
                        {
                            int dist = Math.abs(X[i] - X[r]) + Math.abs(Y[i] - Y[r]);
                            int before = A[c - 1][i][b - a];
                            if (before != -1 && (A[c][r][b] == -1 || A[c][r][b] > before + dist))
                                A[c][r][b] = before + dist;
                        }
                }
        // extract optimum
        int best = -1;
        for (int r = 0; r < restaurants; ++r)
            for (int b = 0; b <= budget; ++b) {
                int sol = A[courses - 1][r][b];
                if (sol != -1 && (best == -1 || best > sol))
                    best = sol;
            }
        return best;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        courses = in.nextInt();
        restaurants = in.nextInt();
        budget = in.nextInt();
        for (int r = 0; r < restaurants; r++) {
            X[r] = in.nextInt();
            Y[r] = in.nextInt();
            for (int c = 0; c < courses; c++)
                P[r][c] = in.nextInt();
        }
        System.out.println(solve());
    }

}

