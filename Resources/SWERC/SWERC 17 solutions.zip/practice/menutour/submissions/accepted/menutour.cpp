/* Swerc 2017 Menu Tour - C. Dürr
 */

#include <iostream>
#include <algorithm>

using namespace std;

const int MAXC = 20;
const int MAXR = 200;
const int MAXB = 201;

int A[MAXC][MAXR][MAXB];
int P[MAXR][MAXC];
int X[MAXR], Y[MAXR];

int courses, restaurants, budget;

int solve() {
    // initialize
    for (int c = 0; c < courses; ++c)
        for (int r = 0; r < restaurants; ++r)
            for (int b = 0; b <= budget; ++b)
                A[c][r][b] = -1;              // represents +infinity cost
    // base step c = 0
    for (int r = 0; r < restaurants; ++r)
    {
        int b = P[r][0];
        if (b != 0)
            A[0][r][b] = 0;
    }
    // induction step
    for (int c = 1; c < courses; ++c)
        for (int r = 0; r < restaurants; ++r)
            for (int b = 0; b <= budget; ++b)
            {
                int a = P[r][c];
                if (1 <= a && a <= b)
                    for (int i = 0; i < restaurants; ++i)
                    {
                        int dist = abs(X[i] - X[r]) + abs(Y[i] - Y[r]);
                        int before = A[c - 1][i][b - a];
                        if (before != -1 && (A[c][r][b] == -1 || A[c][r][b] > before + dist))
                            A[c][r][b] = before + dist;
                    }
            }
    // extract optimum
    int best = -1;
    for (int r = 0; r < restaurants; ++r)
        for (int b = 0; b <= budget; ++b) {
            int sol = A[courses - 1][r][b];
            if (sol != -1 && (best == -1 || best > sol))
                best = sol;
        }
    return best;
}


int main() {
    cin >> courses >> restaurants >> budget;
    for (int r = 0; r < restaurants; ++r)
    {
        cin >> X[r] >> Y[r];
        for (int c = 0; c < courses; ++c)
            cin >> P[r][c];
    }
    cout << solve() << endl;
    return 0;
}
