#! /usr/bin/env python3
#

import sys

def read_ints(line = None):
    strs = (line or sys.stdin.readline()).split()
    assert all(s == "0" or not s.startswith("0") for s in strs), \
            "leading 0 detected"
    return tuple(int(s) for s in strs)

if __name__ == '__main__':
    n = read_ints()[0]
    assert(n >= 1 and n <= 1000)
    a = read_ints()[0]
    assert(a >= 0 and a <= 100000)
    for line in sys.stdin:
        n-=1
        ints=tuple(map(int,line.split()))
        assert(len(ints) == 2)
        assert(ints[0] >= 0 and ints[0] <= 100)
        assert(ints[1] >= 0 and ints[1] <= 100000000)

    assert(n==0)
    exit(42)
