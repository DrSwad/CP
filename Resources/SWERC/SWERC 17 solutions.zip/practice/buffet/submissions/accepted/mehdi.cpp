#include <algorithm>
#include <cstdio>
#include <vector>

using namespace std;

vector<pair<int, int> > items;

int main() {
  int N, A, v, a;
  scanf("%d%d", &N, &A);
  for (int i = 0; i < N; i++) {
    scanf("%d%d", &v, &a);
    items.push_back(make_pair(-v, a));
  }
  sort(items.begin(), items.end());
  int res = 0;
  for (size_t i = 0; A > 0 && i < items.size(); i++) {
    int a = min(items[i].second, A);
    res -= items[i].first * a;
    A -= a;
  }
  printf("%d\n", res);
  return 0;
}
