#!/usr/bin/python

import sys
sys.stdin.readline()
a = int(sys.stdin.readline())
items = sorted([tuple(int(x) for x in line.split()) for line in sys.stdin.readlines()])
t = 0
while a > 0 and items:
    (v, s) = items.pop()
    t += v * min(a, s)
    a -= s
print(t)
