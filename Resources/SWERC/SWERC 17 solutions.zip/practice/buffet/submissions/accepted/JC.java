
import java.util.*;

class Meal implements Comparable<Meal> {
    final int v, a;
    Meal(int v, int a) { this.v = v; this.a = a; }
    public int compareTo(Meal that) { return that.v - this.v; }
}

class JC {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int a = in.nextInt();
        PriorityQueue<Meal> pq = new PriorityQueue<>();
        while (n-- > 0) {
            int vi = in.nextInt();
            int ai = in.nextInt();
            pq.add(new Meal(vi, ai));
        }
        int ans = 0;
        while (a > 0 && !pq.isEmpty()) {
            Meal m = pq.poll();
            int ma = Math.min(a, m.a);
            ans += m.v * ma;
            a -= ma;
        }
        in.close();
        System.out.println(ans);
    }
}
