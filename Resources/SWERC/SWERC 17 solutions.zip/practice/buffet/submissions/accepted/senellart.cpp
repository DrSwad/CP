#include <iostream>
#include <utility>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
  int n, area;
  cin >> n >> area;

  vector<pair<int,int>> c;

  for(int i=0;i<n;++i) {
    int v, a;
    cin >> v >> a;
    c.push_back(make_pair(v,a));
  }

  sort(c.begin(),c.end(),[](pair<int,int> a,pair<int,int> b) { return a.first>b.first; });

  int total=0;
  for(const auto &p : c) {
    if(area==0)
      break;

    int used=min(p.second,area);
    total+=p.first*min(p.second,area);
    area-=used;
  }

  cout << total;
}
