#!/usr/bin/python

import sys
sys.setrecursionlimit(10000) 
try: input = raw_input  # Python2 compatibility
except NameError: pass

def read_ints():
    return [int(x) for x in raw_input().split()]

def read_prop():
    P = int(raw_input())
    return [read_ints() for _ in range(P)]


MAX_GROUP = 101
MAX_SORBET = 2502
INF = 1000*1000*1000
nbGroups, amountTime, amountMoney = read_ints()
props = [ read_prop() for _ in range(nbGroups)]


def isPossible(H):
    minTime = [ [amountTime+1]*(amountMoney+1) for i in range(H+2)]
    minTime[0][0] = 0
    for g in range(nbGroups):
        nxtminTime = [ [amountTime+1]*(amountMoney+1) for i in range(H+2)]
        for (p_time,p_money,p_satis) in props[g]:
            for nbSat in range(max(0,H+g-nbGroups),min(i,H)+1):
                for mon in range(amountMoney+1-p_money):
                    new_time = minTime[nbSat][mon] + p_time
                    new_money = mon + p_money
                    nxtminTime[nbSat][new_money] = min(nxtminTime[nbSat][new_money],new_time)
                    if p_satis >= H:
                        nxtminTime[nbSat+1][new_money] = min(nxtminTime[nbSat+1][new_money],new_time)
        minTime = nxtminTime
    for a in minTime[H]:
        if a <= amountTime:
            return True
    return False


beg = -1
end=nbGroups+1 
while beg+1 < end:
    mid = (beg+end)//2
    if(isPossible(mid)):
        beg=mid
    else:
        end=mid
print(beg)
