#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int MAX_N = 100;
const int MAX_M = 2500;
const int MAX_T = 2500;

int N, M, T;

int Ms[MAX_N][5];
int Ts[MAX_N][5];
int Ss[MAX_N][5];

short d[2][MAX_N+1][MAX_T+1];

bool h_works(int H) {
  memset(d, -1, sizeof(d));
  d[N%2][H][T] = M;
  bool possible = true;
  for (int n = N - 1; n >= 0; n--) {
    int bcur = n%2;
    int bprev = !bcur;
    possible = false;
    memset(d[bcur], -1, sizeof(d[0]));
    for (int h = 0; h <= H; h++) {
      for (int t = 0; t <= T; t++) {
        short mm = d[bprev][h][t];
        if (mm < 0)
          continue;
        for (int j = 0; j < 5; j++) {
          int t2 = t - Ts[n][j];
          if (t2 < 0)
            continue;
          short m2 = mm - Ms[n][j];
          if (m2 < 0)
            continue;
          int h2 = max(0, h - (Ss[n][j] >= H));
          d[bcur][h2][t2] = max(d[bcur][h2][t2], m2);
          if (h2 <= 0)
            possible = true;
        }
      }
    }
  }
  return possible;
}

int dichot(int mi_inc, int ma_exc) {
  if (ma_exc <= mi_inc + 1)
    return mi_inc;
  int mid = (mi_inc + ma_exc) / 2;
  if (h_works(mid))
    return dichot(mid, ma_exc);
  return dichot(mi_inc, mid);
}

int main() {
  scanf("%d%d%d", &N, &M, &T);

  for (int i = 0; i < N; i++) {
    int p;
    scanf("%d", &p);
    for (int j = 0; j < 5; j++)
      if (j < p)
        scanf("%d%d%d", &Ms[i][j], &Ts[i][j], &Ss[i][j]);
      else
        Ms[i][j] = MAX_M + 1;
  }

  printf("%d\n", dichot(-1, N + 1));
  return 0;
}

