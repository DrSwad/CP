#include <cstdio>
#include <algorithm>
using namespace std;

const int MAX_GROUP = 102 ;
const int MAX_SORBET = 2502 ;
int nbPby, amountTime, amountMoney ;

int timeProp[MAX_GROUP][5], moneyProp[MAX_GROUP][5], satProp[MAX_GROUP][5], nbProp[MAX_GROUP] ;

short minTime[2][MAX_GROUP][MAX_SORBET] ;

inline void min_equal(short &a, const int b) { if(a>b) a=b;}

// dichotomy on the hIndex

bool isPossible(int hIndex)
{
  for(int sat = 0 ; sat <= hIndex ; sat++)
    for(int money = 0 ; money <= amountMoney ; money++)
      minTime[0][sat][money] = amountTime+1 ;
  minTime[0][0][0] = 0 ; // we need 0 time to satisfy 0 / 0 groups with 0 money
  // minimun amount of time to serve all groups after id amount which
  // sat are already satifisifed and with "money" remaining money.
  for(int pby = 0 ; pby < nbPby ; pby++)
    {
      const int cur = pby % 2, nxt = (pby+1)%2 ;
      fill(minTime[nxt][0],minTime[nxt+1][0],amountTime+1);
      
      for(int prop = 0  ; prop < nbProp[pby] ; prop++ )
        for(int nbSat = max(hIndex+pby-nbPby,0) ; nbSat <= min(hIndex,pby) ; nbSat ++ )
          for(int money = 0 ; money+moneyProp[pby][prop] <= amountMoney ; money++ )  {
            const int moneyNeeded = money + moneyProp[pby][prop] ;
            const int timeNeeded = minTime[cur][nbSat][money] +  timeProp[pby][prop] ;
            min_equal(minTime[nxt][nbSat][moneyNeeded],timeNeeded);
            if(satProp[pby][prop] >= hIndex)
              min_equal(minTime[nxt][nbSat+1][moneyNeeded],timeNeeded);
          }
    }
  for(int money = 0 ; money <= amountMoney ; money++ )
    if( minTime[nbPby%2][hIndex][money] <= amountTime )
      return true ;
  return false;
}

int main()
{
  scanf("%d %d %d\n",&nbPby,&amountTime,&amountMoney);
  for(int b = 0 ; b < nbPby ; b++) {
    scanf("%d",nbProp+b) ;
    for(int p = 0 ; p < nbProp[b] ; p++ )
      scanf("%d %d %d\n",timeProp[b]+p,moneyProp[b]+p,satProp[b]+p) ;        
  }
  int beg = -1, end = nbPby+1 ; // beg always possible, end never is
  while(beg + 1 < end) {
    const int mid = (beg+end)/2;
    if(isPossible(mid))
      beg=mid ;
    else
      end=mid ;
  }
  printf("%d\n",beg);
  return 0;
}
