
// Jean-Christophe

import java.util.*;

class Prop {
    final int b, r, s;
    Prop(Scanner in) {
        this.b = in.nextInt(); this.r = in.nextInt(); this.s = in.nextInt(); }
}

class PSG {

    static int N, B, R;
    static Prop[][] passersby;

    static int[][][] memo ;

    // minimum amount of basil to serve the first k passersby
    // j of which have satisfaction >= h, using at most r rose
    static int solve(int r, int k, int j, int h) {
        assert r >= 0 && 0 <= k && k <= N && 0 <= j && j <= N && h <= N;
        if (j > k) return Integer.MAX_VALUE;
        if (k == 0) return 0;
        if (memo[r][j][k] >= 0) return memo[r][j][k]  ;
        int b = Integer.MAX_VALUE;
        // we need to serve passerby k-1 in any way
        for (Prop pr: passersby[k-1])
            if (pr.r <= r) {
                int j1 = j > 0 && pr.s >= h ? j - 1 : j; // greedy
                int b1 = solve(r - pr.r, k - 1, j1, h);
                if (b1 != Integer.MAX_VALUE) b = Math.min(b, pr.b + b1);
            }
        // System.out.println(r +" "+ k +" "+ j +" "+ h +" => "+b);
        memo[r][j][k] = b ;
        return b;
    }

    static void fill() {
        for(int r = 0 ; r <= R ; r++)
            for(int g = 0 ; g <= N ; g++)
                Arrays.fill(memo[r][g],-1);
    }
    
    static int solve() {
        memo = new int[R+1][N+1][N+1];
        int minH = -1, maxH = N+1;
        while (minH + 1 < maxH) {
            int midH = (minH + maxH) >>> 1;
            fill();
            if (solve(R, N, midH, midH) <= B) minH = midH; else maxH = midH;
        }
        assert minH <= N;
        return minH;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        N = in.nextInt();
        B = in.nextInt();
        R = in.nextInt();
        passersby = new Prop[N][];
        for (int p = 0; p < N; p++) {
            int pr = in.nextInt();
            assert pr <= 5;
            passersby[p] = new Prop[pr];
            while (pr-- > 0) passersby[p][pr] = new Prop(in);
        }
        in.close();
        System.out.println(solve());
    }
}

/*
Local Variables:
compile-command: "javac PSG.java"
End:
*/
