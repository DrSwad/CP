#include <cstdio>
#include <vector>

using namespace std;

const int MAX_GROUP = 102 ;
const int MAX_MONEY = 2502 ;

int dyn[MAX_GROUP][MAX_GROUP][MAX_MONEY] ;
int cur_h, N, M, T ;
const int INF = 1000*1000*1000 ;

struct prop {
  int t,m,s ;
} ;
vector<prop> groups[MAX_GROUP] ;

// minimun amount of time to serve all groups after id amount which
// sat are already satifisifed and with "money" remaining money.
int get(int id, int sat, int money) {
  
  if(money < 0 )
    return INF ;

  if(N-id+sat < cur_h)
    return INF ;
  
  if(id >= N)
    return 0 ;

  int & res = dyn[id][sat][money] ;
  if(res == -1 ) {
    res = INF ;
    for(auto & p : groups[id]) {
      const int s = (p.s>= cur_h) ;
      res = min(res,get(id+1,sat+s,money-p.m)+p.t);
    }
  }
  return res;
}

bool sat(int m) {
  cur_h = m;
  fill(dyn[0][0],dyn[MAX_GROUP][0],-1);
  return get(0, 0, M) <= T;
}

int main() {
  scanf("%d %d %d\n",&N,&M,&T);
  for(int i = 0 ; i < N ; i++ ) {
    int p;
    scanf("%d",&p);
    while(p--) {
      prop l ;
      scanf("%d %d %d",&l.m,&l.t,&l.s);
      groups[i].push_back(l);
    }
  }
    
  int l = -1, r = N+1;
  while(l+1<r) {
    const int mid = (r+l)/2 ;
    if(sat(mid))
      l = mid ;
    else
      r = mid ;
  }
  printf("%d\n",l);
}
