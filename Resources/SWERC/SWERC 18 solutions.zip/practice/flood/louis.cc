#include <cstdio>
#include <algorithm>
#include <vector>

/*
  Idea: 
  1/  simulate at beggining for #nodes steps

  if the Louvre is not flooded

        2/ find the path of minimum height from 0 to 1

        3/ simulate #nodes steps after  the river reaches this 
 */

using namespace std;
const int Tm = 100*1000, Nm = 5000, INF = 1000*1000*1000 ;

vector<pair<int,int>> edge;
vector<int> prediction(Tm), measurement(Tm), height(Nm) ;
int nbNodes, nbEdges, nbPred;
const int R = 0, M =1;
vector<pair<int,pair<int,int>>> prim;

void input() {
  scanf("%d %d %d",&nbNodes, &nbEdges,&nbPred);
  for(int n = 0 ; n < nbNodes ; n++)
    scanf("%d",&height[n]);
  for(int n = 0 ; n < nbNodes ; n++)
    scanf("%d",&measurement[n]);
  for(int i = 1 ; i < nbPred ; i++)
    scanf("%d",&prediction[i]);  
  for(int c = 0 ; c < nbEdges ; c++) {
    int f,t;
    scanf("%d %d",&f,&t);
    edge.push_back(make_pair(f,t));
    edge.push_back(make_pair(t,f));
  }
  prediction[0]=measurement[0];
}

int repr[Nm];
int find(int a) {
  if(repr[a]<0)
    return a;  
  return repr[a]=find(repr[a]);
}

void makeunion(pair<int,int> e) {
  int a = find(e.first);
  int b = find(e.second);
  if(a==b)
    return;
  if(repr[a]>repr[b])
    swap(a,b);
  repr[a] += repr[b];
  repr[b] = a;
}

int find_dist() {
  for(auto e : edge)
    prim.push_back(make_pair(max(height[e.first],height[e.second]),e));
  fill(repr,repr+nbNodes,-1);
  sort(prim.begin(),prim.end());
  for(auto i: prim) {
    makeunion(i.second);
    if(find(M)==find(R))
      return i.first;
  }
  return 0;
}

int simul(int from) {
  vector<int> wl = measurement, wlnxt=measurement;
  for(int t = from ; t < min(nbPred,from+nbNodes+3) ; t++) {
    wl[R]=prediction[t];
    fill(wlnxt.begin(),wlnxt.end(),0); 
    if(wl[M])
      return t;
    for(auto e : edge)
      if(wl[e.second])
        wlnxt[e.first] = max(wl[e.second]+height[e.second]-height[e.first],wlnxt[e.first]);
    wl.swap(wlnxt);
  }
  return -1;
}

int main() {
  input();
  int s = simul(0);
  if(s < 0){
    int t = 0;
    const int f = find_dist();
    while(t < nbPred && height[0]+prediction[t]<=f)
      t++;
    s=simul(t);
  }
  printf("%d\n",s);
  return 0;
}
