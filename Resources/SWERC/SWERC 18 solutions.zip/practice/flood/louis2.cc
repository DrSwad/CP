#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>

/*
 Idea: consider only the heights that flood some place (i.e. the
 (A[i]+1) ) and simulate at each phase by checking only the nodes that
 changed heights
 */

using namespace std;
const int Tm = 100*1000+10, Nm = 5000, INF = 1000*1000*1000 ;

vector<int> nxt[Nm];
vector<int> prediction(Tm), measurement(Tm), height(Nm) ;
set<int> useful_height;
int nbNodes, nbEdges, nbPred;
const int M=1, R=0;

int getH(int h) {
  auto i = useful_height.upper_bound(h);
  return *(--i);
}

void input() {
  scanf("%d %d %d",&nbNodes, &nbEdges,&nbPred);
  for(int n = 0 ; n < nbNodes ; n++)
    scanf("%d",&height[n]);
  for(int n = 0 ; n < nbNodes ; n++)
    scanf("%d",&measurement[n]);
  
  useful_height.insert(0);
  useful_height.insert(1e9+10);
  for(int n = 0 ; n < nbNodes ; n++)
    useful_height.insert(height[n]+1);
  for(int n = 0 ; n < nbNodes ; n++)
    measurement[n] = getH(height[n]+measurement[n]);
  for(int i = 1 ; i < nbPred ; i++) {
    scanf("%d",&prediction[i]);
    prediction[i] = getH(height[0]+prediction[i]);
  }
  for(int c = 0 ; c < nbEdges ; c++) {
    int f,t;
    scanf("%d %d",&f,&t);
    nxt[f].push_back(t);
    nxt[t].push_back(f);
  }
}

int simul() {
  vector<int> wl = measurement, wl_nxt = measurement;
  vector<int> todo, nxt_todo ;
  int d = 0;
  for(int i = 0 ; i < nbNodes ; i++)
    if(wl[i] > height[i])
      todo.push_back(i);
  for(int time = 0 ; time < nbPred ; time++) {
    if(wl[M] > height[M])
      return time;
    nxt_todo.clear();
    d+= todo.size();
    for(auto f : todo) {
      for(auto t : nxt[f]) {
        const int ndist = wl[f];
        if(ndist > wl_nxt[t]) {
          if(wl[t] == wl_nxt[t])
            nxt_todo.push_back(t);
          wl_nxt[t] = ndist;
        }
      }
    }
    todo.swap(nxt_todo);
    for(auto i : todo)
      wl[i] = wl_nxt[i] ;
    if(prediction[time+1] > wl[R]) {
      wl[R]=prediction[time+1];
      todo.push_back(R);
    }
  }
  return -1;
}

int main() {
  input();
  printf("%d\n",simul());
  return 0;
}
