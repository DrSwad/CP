#! /usr/bin/python
#


# Idea: consider only the heights that flood some place 
# (i.e. the (A[i]+1) ) and simulate at each phase only 
# the nodes that changed height

import sys
sys.setrecursionlimit(10000) 
try: input = raw_input  # Python2 compatibility
except NameError: pass
N, E, T = [int(x) for x in input().split()]
A = [int(x) for x in input().split()]
I = [int(x) for x in input().split()]
F = [int(x) for x in input().split()]
nxt = [ [] for i in range(N)]
edges = []

for _ in range(E):
    f,t = [int(x) for x in input().split()]
    nxt[f].append(t)
    nxt[t].append(f)

useful = [0]+[a+1 for a in A]

useful.sort()
def find(x):
    l = 0
    r = len(useful)
    while l+1 != r:
        m = (l+r)//2
        if useful[m] <= x:
            l = m
        else:
            r = m
    assert(useful[l] <= x)
    return useful[l]

t=0
WL = [find(I[i]+A[i]) for i in range(N)]
todo = [i for i in range(N) if I[i]]
WL_nxt = [i for i in WL]
for t in range(0,T-1):
    if WL[1] > A[1]:
        print(t)
        exit(0)
        
    nxt_todo = []
    for i in todo:
        for to in nxt[i]:
            ndist = WL[i]
            if ndist > WL_nxt[to]:
                if WL[to] == WL_nxt[to]:
                    nxt_todo.append(to)
                WL_nxt[to] = ndist
    for i in nxt_todo:
        WL[i] = WL_nxt[i]
    todo = nxt_todo
    todo.append(0)
    WL[0] = find(A[0]+F[t])
print(-1)
