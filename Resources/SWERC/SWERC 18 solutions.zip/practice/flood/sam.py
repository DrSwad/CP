#! /usr/bin/python
#
# Python 2 / Python 3

from array import array
import sys
try: input = raw_input  # Python2 compatibility
except NameError: pass

def find(n, cliques):
    while cliques[n] != n:
        cliques[n] = cliques[cliques[n]]
        n = cliques[n]
    return n

def find_min_height_path(edges, A, N):
    edges = sorted((max(A[a], A[b]), a, b) for (a, b) in edges)
    cliques = array('H', range(N))
    for (h, a, b) in edges:
        aa, bb = find(a, cliques), find(b, cliques)
        if aa != bb: cliques[aa] = bb
        if find(0, cliques) == find(1, cliques): return h

def solve():
    N, E, T = [int(x) for x in input().split()]
    A = [int(x) for x in input().split()]
    I = [int(x) for x in input().split()]
    F = [int(x) for x in input().split()]
    edges = [tuple(int(x) for x in input().split()) for _ in range(E)]
    neighbours = [[] for _ in range(N)]
    for (a, b) in edges:
        neighbours[a].append(b)
        neighbours[b].append(a)
    # Find minimum height that water needs to reach to flood the Louvre
    # from the Seine.
    min_height = find_min_height_path(edges, A, N)
    min_river_time = None
    if min_height is not None:
        for t in range(T-1):
            if F[t]+A[0] > min_height:
                min_river_time = t
                break
    # Simulate from the beginning.
    from_beginning = simulate(0, I, F, A, N, neighbours, T)
    # Simulate from the time the river is high enough to flood the Louvre if needed.
    if min_river_time is not None and (from_beginning is None or from_beginning < min_river_time):
        from_river = simulate(min_river_time, I, F, A, N, neighbours, T)
        if from_river is not None and (from_beginning is None or from_river < from_beginning):
            return from_river
    return from_beginning

def simulate(t, I, F, A, N, neighbours, T):
    WL = I
    for t in range(t+1, min(t+N+1, T)):
        WL = [F[t-1]] + [max([0, WL[n]] + [WL[v]+A[v]-A[n]
                                           for v in neighbours[n] if WL[v] > 0])
                         for n in range(1, N)]
        if WL[1] > 0: return t

answer = solve()
print(answer if answer is not None else -1)
