
import java.util.*;

class Edge implements Comparable<Edge> {
  final int src, dst;
  final long height;
  Edge(int src, int dst, long height) {
    this.src = src; this.dst = dst; this.height = height; }
  public int compareTo(Edge that) {
    return this.height < that.height ? -1 : this.height == that.height ? 0 : 1;
  }
}

class UF {
  int[] link, rank;

  UF(int N) {
    link = new int[N];
    for (int v = 0; v < N; v++) link[v] = v;
    rank = new int[N];
  }

  int find(int i) {
    if (link[i] == i) return i;
    return link[i] = find(link[i]);
  }
  void union(int i0, int j0) {
    int i = find(i0), j = find(j0);
    if (i == j) return;
    if (rank[i] < rank[j])
      link[i] =j;
    else {
      link[j] = i;
      if (rank[i] == rank[j])
        rank[j]++;
    }
  }
}

class Flood {

  final static int seine = 0, louvre = 1;
  static int N, E, T;
  static long[] A, I, F;
  static Vector<Edge> edges = new Vector<>();

  static long distance() {
    Collections.sort(edges);
    UF uf = new UF(N);
    for (Edge e: edges) {
      uf.union(e.src, e.dst);
      if (uf.find(seine) == uf.find(louvre))
        return e.height;
    }
    return 0;
  }

  static int simul(int from) {
    long[] wl = I.clone();
    long[] wlnxt = I.clone();
    for(int t = from; t < Math.min(T, from+N+3); t++) {
      wl[seine] = F[t];
      if (wl[louvre] > 0)
        return t;
      wlnxt = wl.clone();
      for(Edge e: edges)
        if (wl[e.src] > 0)
          wlnxt[e.dst] = Math.max(wl[e.src] + A[e.src] - A[e.dst],
                                  wlnxt[e.dst]);
      wl = wlnxt.clone();
    }
    return -1;
  }

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    N = sc.nextInt();
    E = sc.nextInt();
    T = sc.nextInt();
    A = new long[N];
    for (int v = 0; v < N; v++) A[v] = sc.nextLong();
    I = new long[N];
    for (int v = 0; v < N; v++) I[v] = sc.nextLong();
    F = new long[T];
    for (int t = 1; t < T; t++) F[t] = sc.nextLong();
    F[0] = I[0];
    for (int e = 0; e < E; e++) {
      int src = sc.nextInt(), dst = sc.nextInt();
      long h = Math.max(A[src], A[dst]);
      edges.add(new Edge(src, dst, h));
      edges.add(new Edge(dst, src, h));
    }
    int s = simul(0);
    if(s < 0){
      int t = 0;
      long f = distance();
      while (t < T && A[0]+F[t] <= f)
        t++;
      s = simul(t);
    }
    System.out.println(s);
  }

}
