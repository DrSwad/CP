#include <cstdio>
#include <queue>
#include <vector>

using namespace std;

typedef pair<int, int> pii;
typedef long long ll;
typedef pair<ll, int> plli;

const int MAX_I = 1e6;

vector<pii> edges[MAX_I];
bool is_shortest[MAX_I];

ll T[MAX_I];

ll go_back(int i, bool myself) {
  vector<int> st;
  st.push_back(i);
  ll m = 0;
  while (!st.empty()) {
    auto cur = st.back();
    st.pop_back();
    if (is_shortest[cur]) {
      m = max(m, -T[cur]);
      continue;
    }
    for (auto& e : edges[cur])
      if (T[cur] + e.second == T[e.first])
        st.push_back(e.first);
    if (myself)
      T[cur] = 1;
    else
      is_shortest[cur] = true;
  }
  return m;
}

void dijkstra() {
  priority_queue<plli> q;
  q.push(make_pair(0, 0));
  while (!q.empty()) {
    auto cur = q.top();
    q.pop();
    auto cur_node = cur.second;
    auto cur_time = cur.first;
    if ((T[cur_node] < 0 && cur_time <= T[cur_node]) || (cur_node == 0 && cur_time < 0))
      continue;
    T[cur_node] = cur_time;
    for (auto& e : edges[cur_node])
      q.push(make_pair(cur_time - e.second, e.first));
  }
}

int main(void) {

  int I, S, F;
  scanf("%d%d%d", &I, &S, &F);

  for (int s = 0; s < S; s++) {
    int i, j, t;
    scanf("%d%d%d", &i, &j, &t);
    edges[i].push_back(make_pair(j, t));
    edges[j].push_back(make_pair(i, t));
  }

  dijkstra();

  int my_hotel;
  scanf("%d", &my_hotel);

  for (int f = 0; f < F; f++) {
    int h;
    scanf("%d", &h);
    go_back(h, false);
  }

  printf("%lld\n", go_back(my_hotel, true));

  return 0;
}
