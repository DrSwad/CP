#! /usr/bin/python
#
# Python 2 / Python 3

from heapq import *
import sys

# Compute all shortest path lengths from the banquet venue.
def dijkstra():
    to_see = [(0, 0)]
    while to_see:
        (node, time) = heappop(to_see)
        if times[node] is None or time < times[node]:
            times[node] = time
            for (n, t) in neighbours[node]: heappush(to_see, (n, time+t))

# Check back the path from the list of hostels of other people or from
# mine. Return the longest common path.
def back(mine=False):
    to_see = hostels[:1] if mine else hostels[1:]
    together = 0
    while to_see:
        node = to_see.pop()
        tn = times[node]
        if shortest[node]:
            together = max(together, tn)
        else:
            if not mine: shortest[node] = True
            to_see += (n for (n, t) in neighbours[node] if tn == times[n] + t)
    return together if mine else back(True)

I, S, F = [int(x) for x in sys.stdin.readline().split()]
neighbours, times, shortest = [[] for _ in range(I)], [None] * I, [False] * I
for l in range(S):
    a, b, t = [int(x) for x in sys.stdin.readline().split()]
    neighbours[a].append((b, t))
    neighbours[b].append((a, t))
dijkstra()
hostels = [int(x) for x in sys.stdin.readline().split()]
print(back())
