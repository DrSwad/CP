#include <cassert>
#include <cstdlib>
#include <ctime>
#include <functional>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <vector>

int main() {
  std::unordered_set<std::string> monuments;
  for (;;) {
    std::string line;
    if (!std::getline(std::cin, line)) {
      break;
    }
    // Skip the date and space.
    int index = line.find(' ') + 1;
    std::string monument = line.substr(index);
    monuments.insert(monument);
  }
  std::cout << monuments.size() << std::endl;
}
