s = set()
while True:
  try:
    line = raw_input()
  except EOFError:
    break
  s.add(line[len('YYYY-MM-DD '):])
print len(s)

