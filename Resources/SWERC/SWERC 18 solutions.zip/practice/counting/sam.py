#! /usr/bin/python
#
# Put monument names in a set and print its size.
# Python 2 / Python 3

import sys

print(len(set(l[11:] for l in sys.stdin.readlines())))
