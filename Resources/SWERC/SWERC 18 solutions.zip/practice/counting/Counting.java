import java.io.*;
import java.util.HashSet;

class Counting {

  // Use a Set to detect duplicated names.
  public static void main(String[] args) throws IOException {
    HashSet<String> set = new HashSet<>();
    BufferedReader in = // much faster than Scanner
      new BufferedReader(new InputStreamReader(System.in));
    for (String s; (s = in.readLine()) != null; )
      set.add(s.substring(11));
    System.out.println(set.size());
  }

}
