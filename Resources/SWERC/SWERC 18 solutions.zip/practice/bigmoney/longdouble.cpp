#include <iostream>
#include <iomanip>

using namespace std;

int main() {
  // Use long double to get the required precision and range.
  long double total = 0, current;

  while(cin >> current) {
    total+=current;
  }

  // Set output precision to 2 decimal places.
  cout << fixed << setprecision(2) << total;

  return 0;
}
