#!/usr/bin/env python

import sys
import re

if __name__ == '__main__':
    # Detect numbers using a regular expression.
    line_format = re.compile(r"^([0-9]+)\.([0-9]{2})$")

    total = 0
    for line in sys.stdin:
        m=line_format.search(line)
        total += int(m.group(1))*100+int(m.group(2))

    # Print solution using the required precision.
    print "%d.%s%d"%(total // 100, "0" if total % 100 < 10 else "", total % 100)

