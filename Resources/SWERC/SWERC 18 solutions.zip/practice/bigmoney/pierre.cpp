#include <iostream>

using namespace std;

int main() {
  // Use long long to get the required range.
  unsigned long long total=0, current;

  while(cin >> current) {
    char point;
    cin >> point;
    
    int decimal;
    cin >> decimal;

    total+=current*100+decimal;
  }

  unsigned int remainder = total%100;

  // Output by two decimal places, do not forget 0 padding.
  cout << (total/100) << ".";
  cout << (remainder<10?"0":"") << remainder << endl;

  return 0;
}
