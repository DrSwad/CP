import java.io.*;

class Pierre {

  public static void main(String[] args) throws IOException {
    BufferedReader in = // much faster than Scanner
      new BufferedReader(new InputStreamReader(System.in));
    
    long total=0; 

    String line;
    while((line=in.readLine())!=null) {
      String [] strs=line.trim().split("\\.");

      long l=Long.parseLong(strs[0]);
      long d=Long.parseLong(strs[1]);
      total += l*100+d;
    }

    long remainder = total%100;

    // Output using two decimal places.
    System.out.print(total/100);
    System.out.print(".");
    System.out.println(remainder==0?"00":remainder<10?"0"+remainder:remainder);
  }
}
