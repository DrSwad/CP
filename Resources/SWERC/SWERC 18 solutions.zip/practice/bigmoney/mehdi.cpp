#include <cstdio>

typedef long long ll;

int main() {
  ll s = 0;
  for (;;) {
    ll ei, ed;
    if (scanf("%lld.%lld\n", &ei, &ed) != 2)
      break;
    s += ei * 100 + ed;
  }
  printf("%lld.%02lld\n", s / 100, s % 100);
  return 0;
}
